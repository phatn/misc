package tejuco.domain;

public enum Gender {
	
	MALE, FEMALE, UNDEFINED;
	
	@Override
	public String toString() {
		return name().toLowerCase();
	}
}
