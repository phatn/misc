package tejuco.domain;

public class Student extends Person {
	
	private int numOfModules;
	
	private int numOfRepeatModules;
	
	private double amountPaid;
	

	public Student(String id, String firstName, String lastName, Gender gender, String phoneNumber, String address, 
			int numOfModules, int numOfRepeatModules, double amountPaid) {
		
		super(id, firstName, lastName, gender, phoneNumber, address);
		
		this.numOfModules = numOfModules;
		this.numOfRepeatModules = numOfRepeatModules;
		this.amountPaid = amountPaid;
	}


	public int getNumOfModules() {
		return numOfModules;
	}


	public void setNumOfModules(int numOfModules) {
		this.numOfModules = numOfModules;
	}


	public int getNumOfRepeatModules() {
		return numOfRepeatModules;
	}


	public void setNumOfRepeatModules(int numOfRepeatModules) {
		this.numOfRepeatModules = numOfRepeatModules;
	}


	public double getAmountPaid() {
		return amountPaid;
	}


	public void setAmountPaid(double amountPaid) {
		this.amountPaid = amountPaid;
	}
	
	
}
