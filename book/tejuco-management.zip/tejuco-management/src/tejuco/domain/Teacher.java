package tejuco.domain;

public class Teacher extends Person {

	private Department department;
	
	private Designation designation;
	
	private int numOfTeachingHours;

	public Teacher(String id, String firstName, String lastName, Gender gender, String phoneNumber, String address,
			Department department, Designation designation, int numOfTeachingHours) {
		
		super(id, firstName, lastName, gender, phoneNumber, address);
		
		this.department = department;
		this.designation = designation;
		this.numOfTeachingHours = numOfTeachingHours;
	}

	public Department getDepartment() {
		return department;
	}

	public void setDepartment(Department department) {
		this.department = department;
	}

	public Designation getDesignation() {
		return designation;
	}

	public void setDesignation(Designation designation) {
		this.designation = designation;
	}

	public int getNumOfTeachingHours() {
		return numOfTeachingHours;
	}

	public void setNumOfTeachingHours(int numOfTeachingHours) {
		this.numOfTeachingHours = numOfTeachingHours;
	}
	
}
