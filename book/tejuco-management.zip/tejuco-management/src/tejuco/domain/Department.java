package tejuco.domain;

public enum Department {
	
	BUSINESS, COMPUTING;
	
	@Override
	public String toString() {
		
		return name().toLowerCase();
	}
}
