package tejuco.domain;

public enum Designation {

	HOF("Head of faculty"), CO("Coordinator"), L("Lecturer");
	
	private String value;
	
	private Designation(String value) {
		this.value = value;
	}
	
	public String getValue() {
		return value;
	}
	
	@Override
	public String toString() {
		return value;
	}
}
