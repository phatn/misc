package tejuco.form;

import java.awt.CardLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSeparator;
import javax.swing.JTable;

import tejuco.domain.Student;

public class MainApplication {

	private JFrame frmMain;
	
	private StudentAddNewForm dialog;
	
	private List<Student> students = new ArrayList<>();
	private JTable tblStudent;

	private static final String[] columns = {"ID", "First Name", "Last Name", "Gender", 
			"Phone Number", "Address", "Num of Modules", "Num of Repeat Modules", "Amount Paid"};
	
	private static final int TUITION_FEE = 525;
	
	private static final int TUITION_FEE_REPEAT = 110;
	
	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainApplication window = new MainApplication();
					window.frmMain.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public MainApplication() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmMain = new JFrame();
		frmMain.setTitle("Main Application");
		frmMain.setBounds(100, 100, 585, 368);
		frmMain.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frmMain.setJMenuBar(menuBar);
		
		JMenu mnManage = new JMenu("Manage");
		menuBar.add(mnManage);
		
		JMenu mnStudent = new JMenu("Student");
		mnManage.add(mnStudent);
		
		JMenuItem mntmNew = new JMenuItem("New");
		
		mntmNew.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				try {
					dialog = new StudentAddNewForm(MainApplication.this);
					dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
					dialog.setVisible(true);
				} catch (Exception ex) {
					ex.printStackTrace();
				}
			}
		});
		mnStudent.add(mntmNew);
		
		JMenuItem mntmViewAll = new JMenuItem("View all");
		
		mnStudent.add(mntmViewAll);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("View all with zero balance");
		
		
		mnStudent.add(mntmNewMenuItem);
		
		JMenuItem mntmViewAllWith = new JMenuItem("View all with non-zero balance");
		
		mnStudent.add(mntmViewAllWith);
		
		JSeparator separator = new JSeparator();
		mnManage.add(separator);
		
		JMenu mnTeacher = new JMenu("Teacher");
		mnManage.add(mnTeacher);
		
		JMenuItem mntmNew_1 = new JMenuItem("New");
		mnTeacher.add(mntmNew_1);
		
		JMenuItem mntmViewAll_1 = new JMenuItem("View all");
		mnTeacher.add(mntmViewAll_1);
		
		JSeparator separator_1 = new JSeparator();
		mnManage.add(separator_1);
		
		JMenuItem mntmExit = new JMenuItem("Exit");
		mnManage.add(mntmExit);
		frmMain.getContentPane().setLayout(new CardLayout(0, 0));
		
		JPanel pnlStudent = new JPanel();
		pnlStudent.setVisible(false);
		frmMain.getContentPane().add(pnlStudent, "name_6268127843990");
		
		tblStudent = new JTable();
		
		
		// View all students
		mntmViewAll.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				
				Object[][] data = new Object[students.size()][9];
				for(int i = 0; i < students.size(); i++) {
					data[i][0] = students.get(i).getId();
					data[i][1] = students.get(i).getFirstName();
					data[i][2] = students.get(i).getLastName();
					data[i][3] = students.get(i).getGender();
					data[i][4] = students.get(i).getPhoneNumber();
					data[i][5] = students.get(i).getAddress();
					data[i][6] = students.get(i).getNumOfModules();
					data[i][7] = students.get(i).getNumOfRepeatModules();
					data[i][8] = students.get(i).getAmountPaid();
					
				}
				
				tblStudent = new JTable(data, columns);
				
				
				pnlStudent.add(tblStudent);
			}
		});
		
		
		// View all with zero balance
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				
				List<Student> zeroBalanceStudents = new ArrayList<>();
				for(Student student : students) {
					if(student.getAmountPaid() == student.getNumOfModules() * TUITION_FEE + student.getNumOfRepeatModules() * TUITION_FEE_REPEAT) {
						zeroBalanceStudents.add(student);
					}
				}
				
				Object[][] data = new Object[zeroBalanceStudents.size()][9];
				for(int i = 0; i < zeroBalanceStudents.size(); i++) {
					data[i][0] = zeroBalanceStudents.get(i).getId();
					data[i][1] = zeroBalanceStudents.get(i).getFirstName();
					data[i][2] = zeroBalanceStudents.get(i).getLastName();
					data[i][3] = zeroBalanceStudents.get(i).getGender();
					data[i][4] = zeroBalanceStudents.get(i).getPhoneNumber();
					data[i][5] = zeroBalanceStudents.get(i).getAddress();
					data[i][6] = zeroBalanceStudents.get(i).getNumOfModules();
					data[i][7] = zeroBalanceStudents.get(i).getNumOfRepeatModules();
					data[i][8] = zeroBalanceStudents.get(i).getAmountPaid();
					
				}
				
				
				tblStudent = new JTable(data, columns);
				
				pnlStudent.add(tblStudent);
			}
		});
		
		
		// View all with non-zero balance
		mntmViewAllWith.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				List<Student> nonZeroBalanceStudents = new ArrayList<>();
				for(Student student : students) {
					if(student.getAmountPaid() != student.getNumOfModules() * TUITION_FEE + student.getNumOfRepeatModules() * TUITION_FEE_REPEAT) {
						nonZeroBalanceStudents.add(student);
					}
				}
				
				Object[][] data = new Object[nonZeroBalanceStudents.size()][9];
				for(int i = 0; i < nonZeroBalanceStudents.size(); i++) {
					data[i][0] = nonZeroBalanceStudents.get(i).getId();
					data[i][1] = nonZeroBalanceStudents.get(i).getFirstName();
					data[i][2] = nonZeroBalanceStudents.get(i).getLastName();
					data[i][3] = nonZeroBalanceStudents.get(i).getGender();
					data[i][4] = nonZeroBalanceStudents.get(i).getPhoneNumber();
					data[i][5] = nonZeroBalanceStudents.get(i).getAddress();
					data[i][6] = nonZeroBalanceStudents.get(i).getNumOfModules();
					data[i][7] = nonZeroBalanceStudents.get(i).getNumOfRepeatModules();
					data[i][8] = nonZeroBalanceStudents.get(i).getAmountPaid();
					
				}
				
				
				tblStudent = new JTable(data, columns);
				
				pnlStudent.add(tblStudent);
				
			}
		});
				
		JPanel pnlTeacher = new JPanel();
		pnlTeacher.setVisible(false);
		frmMain.getContentPane().add(pnlTeacher, "name_6408474086788");
	}

	public List<Student> getStudents() {
		return students;
	}
	

}
