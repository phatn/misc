package tejuco.form;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.UUID;

import javax.swing.DefaultComboBoxModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;

import tejuco.domain.Gender;
import tejuco.domain.Student;

public class StudentAddNewForm extends JDialog {

	private static final long serialVersionUID = 1L;
	
	private final JPanel contentPanel = new JPanel();
	private JTextField txtFirstName;
	private JTextField txtLastName;
	private JTextField txtPhoneNumber;
	private JTextField txtNumOfModules;
	private JTextField txtNumOfRepeatModules;
	private JTextField txtAmountPaid;

	private MainApplication mainApplication;
	
	private JPanel buttonPane;
	
	private JButton okButton;
	
	
	/**
	 * Launch the application.
	 */
	/*
	 * public static void main(String[] args) { try { StudentAddNewForm dialog = new
	 * StudentAddNewForm();
	 * dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
	 * dialog.setVisible(true); } catch (Exception e) { e.printStackTrace(); } }
	 */

	
	/**
	 * Create the dialog.
	 */
	public StudentAddNewForm(MainApplication mainApplication) {
		
		this.mainApplication = mainApplication;
		
		setTitle("Student - Add new");
		setBounds(100, 100, 536, 406);
		getContentPane().setLayout(new BorderLayout());
		contentPanel.setBorder(new EmptyBorder(5, 5, 5, 5));
		getContentPane().add(contentPanel, BorderLayout.CENTER);
		contentPanel.setLayout(null);
		
		JLabel lblCreateANew = new JLabel("Create a new student");
		lblCreateANew.setFont(new Font("Lucida Grande", Font.BOLD, 14));
		lblCreateANew.setBounds(159, 6, 203, 26);
		contentPanel.add(lblCreateANew);
		
		JLabel lblNewLabel = new JLabel("First Name");
		lblNewLabel.setBounds(27, 48, 84, 16);
		contentPanel.add(lblNewLabel);
		
		JLabel lblLastName = new JLabel("Last Name");
		lblLastName.setBounds(27, 76, 84, 16);
		contentPanel.add(lblLastName);
		
		JLabel lblGender = new JLabel("Gender");
		lblGender.setBounds(27, 104, 61, 16);
		contentPanel.add(lblGender);
		
		JLabel lblPhoneNumber = new JLabel("Phone Number");
		lblPhoneNumber.setBounds(27, 132, 111, 16);
		contentPanel.add(lblPhoneNumber);
		
		JLabel lblAddress = new JLabel("Address");
		lblAddress.setBounds(27, 183, 61, 16);
		contentPanel.add(lblAddress);
		
		JLabel lblNumberOfModules = new JLabel("Number of Modules");
		lblNumberOfModules.setBounds(30, 232, 124, 16);
		contentPanel.add(lblNumberOfModules);
		
		JLabel lblNumberOfRepeat = new JLabel("Number of Repeat Modules");
		lblNumberOfRepeat.setBounds(27, 260, 184, 16);
		contentPanel.add(lblNumberOfRepeat);
		
		JLabel lblAmountPaid = new JLabel("Amount Paid");
		lblAmountPaid.setBounds(27, 288, 184, 16);
		contentPanel.add(lblAmountPaid);
		
		txtFirstName = new JTextField();
		txtFirstName.setBounds(222, 43, 286, 26);
		contentPanel.add(txtFirstName);
		txtFirstName.setColumns(10);
		
		txtLastName = new JTextField();
		txtLastName.setColumns(10);
		txtLastName.setBounds(222, 71, 286, 26);
		contentPanel.add(txtLastName);
		
		txtPhoneNumber = new JTextField();
		txtPhoneNumber.setColumns(10);
		txtPhoneNumber.setBounds(222, 122, 286, 26);
		contentPanel.add(txtPhoneNumber);
		
		txtNumOfModules = new JTextField();
		txtNumOfModules.setColumns(10);
		txtNumOfModules.setBounds(222, 227, 286, 26);
		contentPanel.add(txtNumOfModules);
		
		txtNumOfRepeatModules = new JTextField();
		txtNumOfRepeatModules.setColumns(10);
		txtNumOfRepeatModules.setBounds(222, 255, 286, 26);
		contentPanel.add(txtNumOfRepeatModules);
		
		txtAmountPaid = new JTextField();
		txtAmountPaid.setColumns(10);
		txtAmountPaid.setBounds(222, 283, 286, 26);
		contentPanel.add(txtAmountPaid);
		
		JTextArea txtAddress = new JTextArea();
		txtAddress.setBounds(222, 170, 284, 44);
		contentPanel.add(txtAddress);
		
		JComboBox cboGender = new JComboBox();
		cboGender.setModel(new DefaultComboBoxModel(Gender.values()));
		cboGender.setBounds(222, 100, 111, 27);
		contentPanel.add(cboGender);
		
		
			buttonPane = new JPanel();
			buttonPane.setLayout(new FlowLayout(FlowLayout.RIGHT));
			getContentPane().add(buttonPane, BorderLayout.SOUTH);
			okButton = new JButton("Create");
			
			okButton.addActionListener(new ActionListener() {
				public void actionPerformed(ActionEvent e) {
					
					UUID uuid = UUID.randomUUID();
					String id = uuid.toString();
					String firstName = txtFirstName.getText();
					String lastName = txtLastName.getText();
					Gender gender = (Gender) cboGender.getSelectedItem();
					String phoneNumber = txtPhoneNumber.getText();
					String address = txtAddress.getText();
					int numOfModules = Integer.parseInt(txtNumOfModules.getText());
					int numOfRepeatModules = Integer.parseInt(txtNumOfRepeatModules.getText());
					double amountPaid = Double.parseDouble(txtAmountPaid.getText());
					
				 Student student = new Student(id, firstName, lastName, gender, phoneNumber, address, numOfModules, 
							
							numOfRepeatModules, amountPaid);
					
				mainApplication.getStudents().add(student);
				
				System.out.println(mainApplication.getStudents());
					
				}
			});
				okButton.setActionCommand("OK");
				buttonPane.add(okButton);
				getRootPane().setDefaultButton(okButton);
			{
				JButton cancelButton = new JButton("Cancel");
				cancelButton.addActionListener(new ActionListener() {
					public void actionPerformed(ActionEvent e) {
						StudentAddNewForm.this.dispose();
					}
				});
				cancelButton.setActionCommand("Cancel");
				buttonPane.add(cancelButton);
			}
		}

	
}
